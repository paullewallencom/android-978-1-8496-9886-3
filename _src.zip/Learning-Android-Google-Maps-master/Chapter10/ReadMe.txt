This folder contains the complete Android Studio project for our custom application. Enjoy Coding :)
 


