This folder contains the code snippets given the Chapter

code1.txt - activity_maps.xml
Contains layout code for Google maps Intent application.
code2.txt - MapsActivity.java
Contains Activity code to launch Google map application and display map for a particular location. 
code3.txt - activity_maps.xml 
Contains layout code for navigation using Google maps application.
code4.txt - MapsActivity.java
Contains Activity code for navigation using Google maps application.
code5.txt - MapsActivity.java
Contains Activity code for street view panorama using Google maps application.

 


