This folder contains the code snippets given the Chapter

code1.txt - activity_maps.xml
Contains code for layout for map application.
code2.txt - MapsActivity.java
Contains code for Activity for adding Marker.
code3.txt - info_window.xml 
Contains code for layout for custom information window.
code4.txt - MapsActivity.java
Contains Activity code for custom information window.

