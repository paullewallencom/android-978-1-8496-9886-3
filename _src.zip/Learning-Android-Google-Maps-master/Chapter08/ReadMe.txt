This folder contains the code snippets given the Chapter

code1.txt - activity_maps.xml
Contains layout code for Street View application.
code2.txt - MapsActivity.java
Contains Activity code for Street View application.
code3.txt - activity_maps.xml 
Contains layout code for Street View application to support lower API.
code4.txt - MapsActivity.java
Contains Activity code for Street View application to support lower API.
code5.txt - MapsActivity.java
Contains Activity code for Street View application without callback.
code6.txt - activity_maps.xml
Contains layout code to add Street View dynamically.
code7.txt - MapsActivity.java
Contains Activity code to add Street View dynamically.
code8.txt - dialog_camera.xml
Contains layout code for custom camera dialog.
code9.txt -MapsActivity.java
Contains activity code for custom camea view.
 


