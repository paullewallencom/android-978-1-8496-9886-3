This folder contains the code snippets given the Chapter

code1.txt - activity_main.xml
Contains layout code for location application.
code2.txt - MainActivity.java
Contains Activity code to retrieve location using Android framework location API.
code3.txt - activity_main.xml 
Contains layout code to obtain recent known location.
code4.txt - MainActivity.java
Contains Activity code to obtain recent known location.
code5.txt - activity_main.xml
Contains layout code for locaion updates.
code6.txt - MainActivity.java
Contains activity code for location updates.
code7.txt - GeofenceTransitionService.java
Contains GeofenceTransitionService code for Geofencing.
code8.txt - MainActivity.java
Contains activity code for Geofencing
code9.txt -activity_maps.xml
Contains layout code for map application.
code10.txt -MapsActivity.java
Contains activity code for integrating location data with map. 


