This folder contains the code snippets given the Chapter

code1.txt - activity_maps.xml
Contains layout code.
code2.txt - MapsActivity.java
Contains Activity code to zoom and move camera.
code3.txt - MapsActivity.java 
Activity code to move camera without callback.
code4.txt - activity_maps.xml
Layout code to move camera.
code5.txt - MapsActivity.java
Contains Activity code for move camera and zoom.
code6.txt - dialog_camera.xml
Layout code for moving camera with bearing, tilt, zoom.
code7.txt - MapsActivity.java
Contains Activity code to move camera with bearing, tilt, zoom.
code8.txt - MapsActivity.java
Contains activity code for setting boundaries.
code9.txt -activity_maps.xml
Contains layout code for panning.
code10.txt -MapsActivity.java
Contains activity code for panning.
code11.txt -activity_maps.xml
Contains layout code to start and stop animation.
code12.txt - MapsActivity.java
Contains Activity code to strt and stop animation.


