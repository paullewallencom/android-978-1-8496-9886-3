This folder contains the code snippets given the Chapter

code1.txt - activity_maps.xml
Contains code for layout for basic map application.
code2.txt - MapsActivity.java
Contains code for Activity for basic map application.
code3.txt - activity_maps.xml 
Contains code for layout for adding Fragment Programatically.
code4.txt - MapsActivity.java 
Contains code for Activity to add Fragment Programatically.
code5.txt - MapsActivity.java
Contains code for Activity file to add Fragment Programatically using Support library.
code6.txt - MapsActivity.java
Contains code for Activity file to use Callback method..
