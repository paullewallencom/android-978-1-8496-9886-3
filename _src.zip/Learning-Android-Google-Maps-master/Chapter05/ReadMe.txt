This folder contains the code snippets given the Chapter

code1.txt - activity_maps.xml
Contains layout code layout for map application.
code2.txt - MapsActivity.java
Contains Activity code for enabling zoom control.
code3.txt - MapsActivity.java
Contains Activity code for custom dialog for selecting UI controls.
code4.txt - dialog_add.xml
Contains layout code for custom dialog to add marker for custom application.
code5.txt - MapsActivity.java
Contains activity code for custom application.


