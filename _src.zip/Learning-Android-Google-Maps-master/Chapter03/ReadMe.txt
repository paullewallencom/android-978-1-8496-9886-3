This folder contains the code snippets given the Chapter

code1.txt - activity_maps.xml
Contains code for layout for basic map application.
code2.txt - MapsActivity.java
Contains code for Activity for Normal map application.
code3.txt - activity_maps.xml 
Contains code for layout for custom map application.
code4.txt - popup.xml 
Contains code for pop up menu.
code5.txt - MapsActivity.java
Contains code for Activity file for custom map application.
code6.txt - activity_maps.xml
Contains code for layout for lite mode.
